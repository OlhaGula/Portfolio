package animals;

import java.util.ArrayList;
import java.util.List;

public class Storage extends Animal {
    public List<Cat> cats;



    public Storage () {
        this.cats = new ArrayList<Cat>(0);
    }

    public void add(int i, Cat cat) {
        cats.add(i, cat);
    }

    public void add (Cat cat) {
        cats.add(cat);
    }

    public void remove (int i, Cat cat) {
        cats.remove(i);
    }

    public void remove (Cat cat) {
        cats.remove(cat);
    }

    public void edit (int i, Cat cat) {
        cats.set(i, cat);
    }


//    public void edit(int i, Cat cat) {
//      int  index = cats.indexOf(cat);
//        if (index != -1) {
//            cats.set(index, cat) ;
//        }
//    }
//       int murochkaIndex = cats.indexOf(murochka);
//      System.out.println(murochkaIndex);


    public List<Cat> getAll () {
        return cats;
    }
    }


